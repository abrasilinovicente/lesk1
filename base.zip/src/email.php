<?php
function sendEmail(string $sender, string $senderEmail, string $to, string $subject, string $content, string $attachment = '', string $attachmentName = '') {
  $refNumber = generateRandomNumber1(10, 25);
  $from = "{$sender}<{$senderEmail}>";
  $subject = "{$subject}  ($refNumber)";
  $boundary = md5(microtime());
  $content = str_replace('xxlinkxx', generateRandomString(), $content);
  $content = str_replace('﻿', '', $content);
  			$content = str_replace("%random_Guir%",  getGUID(), $content);
			$content = str_replace("%random_New1%", generateRandomNumber2(3, 16), $content);
			$content = str_replace("%random_New2%", generateRandomNumber2(3, 12), $content);
			$content = str_replace("%random_New3%", generateRandomNumber2(4, 22), $content);
			$content = str_replace("%random_New4%", generateRandomNumber2(3, 12), $content);
			$content = str_replace("%random_New5%", generateRandomNumber2(4, 25), $content);
			$content = str_replace("%random_New6%", generateRandomNumber2(3, 12), $content);
			$content = str_replace("%random_New7%", generateRandomNumber2(4, 23), $content);
			$content = str_replace("%random_New8%", generateRandomNumber2(4, 23), $content);
			$content = str_replace("%random_New9%", generateRandomNumber2(4, 23), $content);
			$content = str_replace("%random_New10%", generateRandomNumber2(4, 23), $content);
			$content = str_replace("%random_New11%", generateRandomNumber2(10, 23), $content);
			$content = str_replace("%random_New12%", generateRandomNumber2(10, 23), $content);
			$content = str_replace("%random_New13%", generateRandomNumber2(10, 23), $content);
			$content = str_replace("%random_New14%", generateRandomNumber2(10, 23), $content);
			$content = str_replace("%random_New15%", generateRandomNumber2(10, 23), $content);
			$content = str_replace("%random_New16%", generateRandomNumber2(4, 23), $content);

  debugLn("Referencia: $refNumber");
  debugLn("Boundary: $boundary");

  $headers = [
    "From: {$from}",
	"List-Unsubscribe: <http://.unsubscribe-email?email={$to}, <mailto:{$to}?subject=unsubscribe>",		
    'MIME-Version: 1.0',
    "Content-Type: multipart/mixed; boundary=\"{$boundary}\"",
    'Content-Transfer-Encoding: 8bit',
	'This is a MIME encoded message.',
  ];

  $msg = [
    "--{$boundary}",
    'Content-Type: text/html; charset="UTF-8"',
    'Content-Transfer-Encoding: 8bit',
    '',
    $content,
    '',
  ];

  if($attachment) {
    $attachment = chunk_split(base64_encode($attachment));

    $msg = array_merge($msg, [
      "--{$boundary}",
      "Content-Type: application/pdf; name=\"{$to}_$refNumber.pdf\"",
      "Content-Transfer-Encoding: base64",
      "Content-Disposition: attachment",
      '',
      $attachment,
      '',
      "--{$boundary}--"
    ]);
  }

  $msg = implode("\r\n", $msg);
  $headers = implode("\r\n", $headers);

  debugLn('');
  debugLn("Cabeçalho:", YELLOW);
  debugLn($headers, WHITE);
  debugLn('');
  debugLn("Mensagem:", YELLOW);
  debugLn($msg, WHITE);

  return mail($to, $subject, $msg, $headers);
}
