<?php
/**
 * Sistema Profissional de Envio de Email
 * Suporte completo para multipart/alternative e multipart/mixed
 */

/**
 * Envia email com suporte a HTML, texto simples e anexos
 * 
 * @param string $sender Nome do remetente
 * @param string $senderEmail Email do remetente
 * @param string $to Email do destinatário
 * @param string $subject Assunto do email
 * @param string $content Conteúdo HTML do email
 * @param string|null $attachment Conteúdo binário do anexo
 * @param string|null $attachmentName Nome do arquivo anexo
 * @return bool Sucesso no envio
 */
function sendEmail(
    string $sender, 
    string $senderEmail, 
    string $to, 
    string $subject, 
    string $content, 
    ?string $attachment = null, 
    ?string $attachmentName = null
): bool {
    // Gerar identificadores únicos
    $messageId = generateMessageId($senderEmail);
    $refNumber = generateRandomNumber(10, 25);
    $boundary_mixed = generateBoundary('MIXED');
    $boundary_alt = generateBoundary('ALT');
    
    debugLn("Message-ID: $messageId");
    debugLn("Reference: $refNumber");
    
    // Processar o conteúdo HTML com substituições
    $htmlContent = processContent($content, $to, $refNumber);
    
    // IMPORTANTE: Garantir que HTML seja bem formatado antes de converter
    $htmlContent = ensureProperHtmlFormat($htmlContent);
    
    // Gerar versão texto simples do HTML
    $textContent = generateTextFromHtml($htmlContent);
    
    // Verificar similaridade entre HTML e texto
    validateContentSimilarity($htmlContent, $textContent);
    
    // Adicionar número de referência ao assunto
//  $subject = "{$subject} (#$refNumber)";
    $subject = "{$subject}";
    
    // Construir cabeçalhos profissionais
    $headers = buildHeaders($sender, $senderEmail, $to, $messageId, $boundary_mixed);
    
    // Construir corpo da mensagem
    if ($attachment && $attachmentName) {
        // Email com anexo (multipart/mixed contendo multipart/alternative)
        $message = buildMessageWithAttachment(
            $textContent, 
            $htmlContent, 
            $attachment, 
            $attachmentName, 
            $boundary_mixed, 
            $boundary_alt,
            $to,
            $refNumber
        );
    } else {
        // Email sem anexo (apenas multipart/alternative)
        $headers = buildHeaders($sender, $senderEmail, $to, $messageId, $boundary_alt, false);
        $message = buildMessageWithoutAttachment(
            $textContent, 
            $htmlContent, 
            $boundary_alt
        );
    }
    
    // Debug da mensagem final
    if (defined('DEBUG')) {
        debugLn("\n=== CABEÇALHOS ===", YELLOW);
        debugLn($headers, WHITE);
        debugLn("\n=== TEXTO SIMPLES (primeiros 300 chars) ===", YELLOW);
        debugLn(substr($textContent, 0, 300) . '...', WHITE);
        debugLn("\n=== HTML (primeiros 300 chars) ===", YELLOW);
        debugLn(substr($htmlContent, 0, 300) . '...', WHITE);
    }
    
    // Enviar email
    $result = @mail($to, $subject, $message, $headers);
    
    if ($result) {
        logEmailSent($to, $subject, $refNumber);
    } else {
        logEmailFailed($to, $subject, error_get_last()['message'] ?? 'Unknown error');
    }
    
    return $result;
}

/**
 * Processa o conteúdo HTML com substituições dinâmicas
 */
function processContent(string $content, string $to, string $refNumber): string {
    // Remover BOM UTF-8 se presente
    $content = str_replace("\xEF\xBB\xBF", '', $content);
    
    // Substituições de placeholders
    $replacements = [
        '%email%' => $to,
        '%ref%' => $refNumber,
        '%date%' => date('Y-m-d'),
        '%datetime%' => date('Y-m-d H:i:s'),
        '%timestamp%' => time(),
        '%random_guid%' => getGUID(),
        'xxlinkxx' => generateRandomString(32),
    ];
    
    // Substituições dinâmicas numeradas
    for ($i = 1; $i <= 20; $i++) {
        $replacements["%random_New{$i}%"] = generateRandomNumber(4, 23);
    }
    
    // Aplicar todas as substituições
    foreach ($replacements as $search => $replace) {
        $content = str_replace($search, $replace, $content);
    }
    
    // Garantir encoding UTF-8 correto
    if (!mb_check_encoding($content, 'UTF-8')) {
        $content = mb_convert_encoding($content, 'UTF-8', 'auto');
    }
    
    return $content;
}

/**
 * Gera versão texto simples a partir do HTML mantendo máxima fidelidade
 */
function generateTextFromHtml(string $html): string {
    // Salvar o HTML original para comparação
    $originalHtml = $html;
    
    // Primeiro, remover apenas scripts e styles (não o conteúdo)
    $text = preg_replace('/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/mi', '', $html);
    $text = preg_replace('/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/mi', '', $text);
    
    // Remover comentários HTML
    $text = preg_replace('/<!--.*?-->/s', '', $text);
    
    // Preservar estrutura de títulos
    $text = preg_replace('/<h1[^>]*>(.*?)<\/h1>/i', "\n\n=== $1 ===\n\n", $text);
    $text = preg_replace('/<h2[^>]*>(.*?)<\/h2>/i', "\n\n== $1 ==\n\n", $text);
    $text = preg_replace('/<h3[^>]*>(.*?)<\/h3>/i', "\n\n= $1 =\n", $text);
    $text = preg_replace('/<h[4-6][^>]*>(.*?)<\/h[4-6]>/i', "\n\n$1\n", $text);
    
    // Preservar ênfases
    $text = preg_replace('/<strong[^>]*>(.*?)<\/strong>/i', '*$1*', $text);
    $text = preg_replace('/<b[^>]*>(.*?)<\/b>/i', '*$1*', $text);
    $text = preg_replace('/<em[^>]*>(.*?)<\/em>/i', '_$1_', $text);
    $text = preg_replace('/<i[^>]*>(.*?)<\/i>/i', '_$1_', $text);
    $text = preg_replace('/<u[^>]*>(.*?)<\/u>/i', '_$1_', $text);
    
    // Converter listas não ordenadas
    $text = preg_replace('/<li[^>]*>(.*?)<\/li>/i', "\n • $1", $text);
    $text = preg_replace('/<ul[^>]*>(.*?)<\/ul>/is', "\n$1\n", $text);
    $text = preg_replace('/<ol[^>]*>(.*?)<\/ol>/is', "\n$1\n", $text);
    
    // Preservar links com texto descritivo
    $text = preg_replace_callback(
        '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/i',
        function($matches) {
            $url = $matches[1];
            $linkText = strip_tags($matches[2]);
            
            // Se o texto do link é igual à URL, mostrar apenas uma vez
            if ($linkText == $url || empty($linkText)) {
                return $url;
            }
            
            // Se é um link mailto, simplificar
            if (strpos($url, 'mailto:') === 0) {
                return $linkText;
            }
            
            // Para outros links, mostrar texto e URL
            return "{$linkText} ({$url})";
        },
        $text
    );
    
    // Converter tabelas em formato texto
    $text = preg_replace('/<table[^>]*>/i', "\n", $text);
    $text = preg_replace('/<\/table>/i', "\n", $text);
    $text = preg_replace('/<tr[^>]*>/i', "\n", $text);
    $text = preg_replace('/<\/tr>/i', "", $text);
    $text = preg_replace('/<t[hd][^>]*>(.*?)<\/t[hd]>/i', " | $1", $text);
    
    // Converter quebras de linha e parágrafos
    $text = preg_replace('/<br\s*\/?>/i', "\n", $text);
    $text = preg_replace('/<\/p>/i', "\n\n", $text);
    $text = preg_replace('/<p[^>]*>/i', "", $text);
    $text = preg_replace('/<\/div>/i', "\n", $text);
    $text = preg_replace('/<div[^>]*>/i', "", $text);
    
    // Adicionar linha horizontal para <hr>
    $text = preg_replace('/<hr\s*\/?>/i', "\n" . str_repeat('-', 60) . "\n", $text);
    
    // Preservar blocos de código
    $text = preg_replace('/<code[^>]*>(.*?)<\/code>/i', '`$1`', $text);
    $text = preg_replace('/<pre[^>]*>(.*?)<\/pre>/is', "\n```\n$1\n```\n", $text);
    
    // Remover todas as tags HTML restantes
    $text = strip_tags($text);
    
    // Decodificar entidades HTML
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    
    // Limpar espaços mas preservar estrutura
    $text = preg_replace('/[ \t]+/', ' ', $text); // Espaços horizontais
    $text = preg_replace('/^ +/m', '', $text);    // Espaços no início das linhas
    $text = preg_replace('/ +$/m', '', $text);    // Espaços no fim das linhas
    $text = preg_replace('/\n{3,}/', "\n\n", $text); // Máximo 2 quebras de linha
    
    // Remover quebras de linha no início e fim
    $text = trim($text);
    
    // Se o texto ficou muito curto comparado ao HTML, há algo errado
    $htmlLength = strlen(strip_tags($originalHtml));
    $textLength = strlen($text);
    
    if ($textLength < ($htmlLength * 0.5)) {
        // Fallback para conversão simples se algo deu errado
        $text = strip_tags($originalHtml);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\s+/', ' ', $text);
        $text = wordwrap($text, 75, "\n", true);
    }
    
    // Adicionar rodapé discreto apenas se o texto for muito curto
    if ($textLength < 100) {
        $text .= "\n\n" . str_repeat('-', 60);
        $text .= "\nEste email também está disponível em formato HTML.";
    }
    
    return $text;
}

/**
 * Constrói cabeçalhos profissionais do email
 */
function buildHeaders(
    string $sender, 
    string $senderEmail, 
    string $to, 
    string $messageId, 
    string $boundary,
    bool $hasMixed = true
): string {
    $domain = substr(strrchr($senderEmail, "@"), 1);
    $fromHeader = sprintf('"%s" <%s>', $sender, $senderEmail);
    
    $headers = [
        "From: {$fromHeader}",
        "Return-Path: {$senderEmail}",
        "Message-ID: {$messageId}",
        "X-Priority: 3",
        "X-MSMail-Priority: Normal",
        "MIME-Version: 1.0",
        "Date: " . date('r'),
        "List-Unsubscribe: <mailto:{$senderEmail}?subject=unsubscribe&body=Please%20unsubscribe%20{$to}>",
        "List-Unsubscribe-Post: List-Unsubscribe=One-Click",
    ];
    
    // Adicionar DKIM se configurado
    if (defined('DKIM_SELECTOR') && defined('DKIM_DOMAIN')) {
        $headers[] = sprintf(
            "DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=%s; s=%s;",
            DKIM_DOMAIN,
            DKIM_SELECTOR
        );
    }
    
    // Definir Content-Type baseado no tipo de mensagem
    if ($hasMixed) {
        $headers[] = "Content-Type: multipart/mixed; boundary=\"{$boundary}\"";
    } else {
        $headers[] = "Content-Type: multipart/alternative; boundary=\"{$boundary}\"";
    }
    
    $headers[] = "Content-Transfer-Encoding: 8bit";
    
    return implode("\r\n", $headers);
}

/**
 * Constrói mensagem com anexo (multipart/mixed)
 */
function buildMessageWithAttachment(
    string $textContent,
    string $htmlContent,
    string $attachment,
    string $attachmentName,
    string $boundary_mixed,
    string $boundary_alt,
    string $to,
    string $refNumber
): string {
    $message = [];
    
    // Início do multipart/mixed
    $message[] = "This is a multi-part message in MIME format.";
    $message[] = "";
    $message[] = "--{$boundary_mixed}";
    $message[] = "Content-Type: multipart/alternative; boundary=\"{$boundary_alt}\"";
    $message[] = "";
    
    // Parte texto simples
    $message[] = "--{$boundary_alt}";
    $message[] = "Content-Type: text/plain; charset=UTF-8";
    $message[] = "Content-Transfer-Encoding: 8bit";
    $message[] = "";
    $message[] = $textContent;
    $message[] = "";
    
    // Parte HTML
    $message[] = "--{$boundary_alt}";
    $message[] = "Content-Type: text/html; charset=UTF-8";
    $message[] = "Content-Transfer-Encoding: 8bit";
    $message[] = "";
    $message[] = $htmlContent;
    $message[] = "";
    
    // Fim do multipart/alternative
    $message[] = "--{$boundary_alt}--";
    $message[] = "";
    
    // Anexo
    $message[] = "--{$boundary_mixed}";
    
    // Detectar tipo MIME do anexo
    $mimeType = detectMimeType($attachmentName);
    
    // Gerar nome único para o anexo
    $attachmentDisplayName = generateAttachmentName($attachmentName, $to, $refNumber);
    
    $message[] = "Content-Type: {$mimeType}; name=\"{$attachmentDisplayName}\"";
    $message[] = "Content-Transfer-Encoding: base64";
    $message[] = "Content-Disposition: attachment; filename=\"{$attachmentDisplayName}\"";
    $message[] = "";
    $message[] = chunk_split(base64_encode($attachment), 76);
    $message[] = "";
    
    // Fim do multipart/mixed
    $message[] = "--{$boundary_mixed}--";
    
    return implode("\r\n", $message);
}

/**
 * Constrói mensagem sem anexo (multipart/alternative)
 */
function buildMessageWithoutAttachment(
    string $textContent,
    string $htmlContent,
    string $boundary_alt
): string {
    $message = [];
    
    $message[] = "This is a multi-part message in MIME format.";
    $message[] = "";
    
    // Parte texto simples
    $message[] = "--{$boundary_alt}";
    $message[] = "Content-Type: text/plain; charset=UTF-8";
    $message[] = "Content-Transfer-Encoding: 8bit";
    $message[] = "";
    $message[] = $textContent;
    $message[] = "";
    
    // Parte HTML
    $message[] = "--{$boundary_alt}";
    $message[] = "Content-Type: text/html; charset=UTF-8";
    $message[] = "Content-Transfer-Encoding: 8bit";
    $message[] = "";
    $message[] = $htmlContent;
    $message[] = "";
    
    // Fim do multipart/alternative
    $message[] = "--{$boundary_alt}--";
    
    return implode("\r\n", $message);
}

/**
 * Gera um Message-ID único
 */
function generateMessageId(string $senderEmail): string {
    $domain = substr(strrchr($senderEmail, "@"), 1);
    $uniqueId = md5(uniqid(rand(), true));
    return "<{$uniqueId}@{$domain}>";
}

/**
 * Gera boundary único para multipart
 */
function generateBoundary(string $prefix = 'BOUNDARY'): string {
    return sprintf(
        '===%s_%s_%s===',
        $prefix,
        md5(time()),
        uniqid()
    );
}

/**
 * Detecta tipo MIME baseado na extensão do arquivo
 */
function detectMimeType(string $filename): string {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    $mimeTypes = [
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt' => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'zip' => 'application/zip',
        'rar' => 'application/x-rar-compressed',
        'txt' => 'text/plain',
        'csv' => 'text/csv',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'bmp' => 'image/bmp',
    ];
    
    return $mimeTypes[$extension] ?? 'application/octet-stream';
}

/**
 * Gera nome personalizado para o anexo
 */
function generateAttachmentName(string $originalName, string $to, string $refNumber): string {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $baseName = pathinfo($originalName, PATHINFO_FILENAME);
    
    // Extrair nome do destinatário (antes do @)
    $recipientName = strstr($to, '@', true);
    $recipientName = preg_replace('/[^a-zA-Z0-9]/', '', $recipientName);
    
    // Gerar nome único
    return sprintf(
        '%s_%s_%s.%s',
        substr($baseName, 0, 20),
        substr($recipientName, 0, 10),
        $refNumber,
        $extension
    );
}

/**
 * Registra email enviado com sucesso
 */
function logEmailSent(string $to, string $subject, string $ref): void {
    if (defined('LOG_EMAILS') && LOG_EMAILS) {
        $logFile = 'emails_sent.log';
        $logEntry = sprintf(
            "[%s] SUCCESS | To: %s | Subject: %s | Ref: %s\n",
            date('Y-m-d H:i:s'),
            $to,
            $subject,
            $ref
        );
        @file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
}

/**
 * Registra falha no envio
 */
function logEmailFailed(string $to, string $subject, string $error): void {
    if (defined('LOG_EMAILS') && LOG_EMAILS) {
        $logFile = 'emails_failed.log';
        $logEntry = sprintf(
            "[%s] FAILED | To: %s | Subject: %s | Error: %s\n",
            date('Y-m-d H:i:s'),
            $to,
            $subject,
            $error
        );
        @file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
}

/**
 * Valida se o email está em formato correto
 */
function validateEmailFormat(string $email): bool {
    // Validação rigorosa de email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    
    // Verificar MX records (opcional, pode ser lento)
    if (defined('VERIFY_MX') && VERIFY_MX) {
        $domain = substr(strrchr($email, "@"), 1);
        if (!checkdnsrr($domain, "MX")) {
            return false;
        }
    }
    
    return true;
}

/**
 * Função auxiliar para testar envio
 */
function testEmailSending(string $to = 'test@example.com'): bool {
    debugLn("\n=== TESTE DE ENVIO DE EMAIL ===", YELLOW);
    
    $testHtml = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Email de Teste</title>
    </head>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #333;">Email de Teste</h1>
        <p>Este é um email de teste enviado em <strong>%datetime%</strong>.</p>
        <p>Número de referência: <code>%ref%</code></p>
        <p>ID único: <code>%random_guid%</code></p>
        <hr style="border: 1px solid #ddd;">
        <p style="color: #666; font-size: 12px;">
            Se você recebeu este email, o sistema está funcionando corretamente.
        </p>
    </body>
    </html>
    ';
    
    $result = sendEmail(
        'Sistema de Teste',
        'noreply@example.com',
        $to,
        'Teste de Envio',
        $testHtml
    );
    
    if ($result) {
        debugLn("✓ Email de teste enviado com sucesso!", GREEN);
    } else {
        debugLn("✗ Falha no envio do email de teste!", RED);
    }
    
    return $result;
}

/**
 * Garante que o HTML esteja bem formatado
 */
function ensureProperHtmlFormat(string $html): string {
    // Se não tem doctype, adicionar estrutura HTML completa
    if (stripos($html, '<!DOCTYPE') === false && stripos($html, '<html') === false) {
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
' . $html . '
</body>
</html>';
    }
    
    // Garantir que tenha tags body
    if (stripos($html, '<body') === false) {
        $html = preg_replace('/<html[^>]*>/i', '$0<body>', $html);
        $html = preg_replace('/<\/html>/i', '</body>$0', $html);
    }
    
    return $html;
}

/**
 * Valida se o conteúdo texto e HTML são similares o suficiente
 */
function validateContentSimilarity(string $html, string $text): void {
    // Extrair apenas texto visível do HTML para comparação
    $htmlText = strip_tags($html);
    $htmlText = html_entity_decode($htmlText, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $htmlText = preg_replace('/\s+/', ' ', $htmlText);
    $htmlText = trim($htmlText);
    
    // Limpar texto para comparação
    $cleanText = preg_replace('/\s+/', ' ', $text);
    $cleanText = trim($cleanText);
    
    // Calcular similaridade
    $htmlLength = strlen($htmlText);
    $textLength = strlen($cleanText);
    
    // Se o texto tem menos de 50% do conteúdo do HTML, há um problema
    if ($textLength < ($htmlLength * 0.4)) {
        debugLn("⚠ Aviso: Versão texto muito diferente do HTML", YELLOW);
        debugLn("  HTML tem {$htmlLength} chars, texto tem {$textLength} chars", YELLOW);
    }
    
    // Debug para verificar conteúdo
    if (defined('DEBUG')) {
        debugLn("\n=== VERIFICAÇÃO DE SIMILARIDADE ===", CYAN);
        debugLn("Tamanho HTML limpo: {$htmlLength} caracteres", WHITE);
        debugLn("Tamanho texto: {$textLength} caracteres", WHITE);
        $percentage = round(($textLength / max($htmlLength, 1)) * 100);
        debugLn("Similaridade: {$percentage}%", WHITE);
    }
}

/**
 * Cria uma versão texto alternativa se a conversão automática falhar
 */
function createFallbackTextVersion(string $html): string {
    // Extrair apenas o conteúdo do body
    if (preg_match('/<body[^>]*>(.*?)<\/body>/is', $html, $matches)) {
        $bodyContent = $matches[1];
    } else {
        $bodyContent = $html;
    }
    
    // Remover scripts, styles e comentários
    $text = preg_replace('/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/mi', '', $bodyContent);
    $text = preg_replace('/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/mi', '', $text);
    $text = preg_replace('/<!--.*?-->/s', '', $text);
    
    // Processar linha por linha para manter estrutura
    $lines = explode("\n", $text);
    $output = [];
    
    foreach ($lines as $line) {
        // Remover tags mas preservar conteúdo
        $line = strip_tags($line);
        $line = html_entity_decode($line, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $line = trim($line);
        
        if (!empty($line)) {
            $output[] = $line;
        }
    }
    
    // Juntar linhas com espaçamento apropriado
    $text = implode("\n\n", $output);
    
    // Limpar espaços extras
    $text = preg_replace('/\n{3,}/', "\n\n", $text);
    
    // Quebrar linhas longas
    $text = wordwrap($text, 75, "\n", true);
    
    return trim($text);
}