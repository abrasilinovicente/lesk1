<?php
require('term.php');

/**
 * Gera um número de referência aleatório de 6 dígitos
 */
function generateRefNumber(): int {
    return mt_rand(111111, 999999);
}

/**
 * Gera uma string numérica aleatória com comprimento variável
 */
function generateRandomNumber($min, $max): string {
    $length = rand($min, $max);
    $result = '';
    
    for ($i = 0; $i < $length; $i++) {
        $result .= mt_rand(0, 9);
    }
    
    return $result;
}

/**
 * Gera um GUID (Globally Unique Identifier)
 */
function getGUID(): string {
    if (function_exists('com_create_guid')) {
        return trim(com_create_guid(), '{}');
    }
    
    // Fallback para sistemas não-Windows
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

/**
 * Gera uma string aleatória com caracteres alfanuméricos e especiais
 */
function generateRandomString(int $length = 16): string {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-';
    $str = '';
    $maxIndex = strlen($chars) - 1;
    
    for($i = 0; $i < $length; $i++) {
        $str .= $chars[mt_rand(0, $maxIndex)];
    }
    
    return $str;
}

/**
 * Escreve mensagem de debug (sem quebra de linha)
 */
function debug(string $msg, int $forecolor = 39, int $backcolor = 49): void {
    if(!defined('DEBUG')) return;
    write(' > ', DEFAULT_COLOR, DEFAULT_COLOR, BOLD);
    write($msg, $forecolor, $backcolor);
}

/**
 * Escreve mensagem de debug (com quebra de linha)
 */
function debugLn(string $msg, int $forecolor = 39, int $backcolor = 49): void {
    if(!defined('DEBUG')) return;
    debug($msg, $forecolor, $backcolor);
    echo "\n";
}

/**
 * Escreve OK em verde para debug
 */
function debugOk(): void {
    debugLn('OK', GREEN);
}

/**
 * Escreve FALHOU em vermelho para debug
 */
function debugFail(string $reason = ''): void {
    $msg = 'FALHOU';
    if ($reason) {
        $msg .= " - $reason";
    }
    debugLn($msg, RED);
}

/**
 * Analisa argumentos da linha de comando
 * Suporta: --key value, --key=value, --flag
 */
function parseArgv(): array {
    $argv = $_SERVER['argv'] ?? [];
    $params = [];
    $lastKey = '';
    
    foreach($argv as $i => $arg) {
        if($i === 0) continue; // Pular nome do script
        
        // Suporte para --key=value
        if(preg_match('/^--([^=]+)=(.*)/', $arg, $matches)) {
            $params[$matches[1]] = $matches[2];
            $lastKey = '';
        }
        // Suporte para --key
        elseif(preg_match('/^--(.+)/', $arg, $matches)) {
            $lastKey = $matches[1];
            $params[$lastKey] = '';
        }
        // Valor para a última key
        elseif($lastKey) {
            $params[$lastKey] = trim($params[$lastKey] . ' ' . $arg);
        }
    }
    
    // Limpar valores
    foreach($params as &$value) {
        $value = trim($value);
    }
    
    return $params;
}

/**
 * Obtém e valida os parâmetros do script
 */
function getParams(): object {
    $params = parseArgv();
    $obj = new stdClass;
    
    // Modo debug
    $obj->debug = isset($params['debug']);
    if($obj->debug) {
        define('DEBUG', true);
        debugLn('');
        debugLn('========= MODO DE DEPURAÇÃO =========', WHITE, BLUE);
        debugLn('Parâmetros recebidos:');
        foreach($params as $key => $value) {
            $displayValue = $value ?: '(flag)';
            debugLn("  --$key: $displayValue", CYAN);
        }
        debugLn('=====================================');
    }
    
    // Delay entre envios (padrão: 2000ms = 2 segundos)
    $obj->delay = isset($params['delay']) 
        ? intval($params['delay']) * 1000  // Converter para microsegundos
        : 2000000; // 2 segundos padrão
    debugLn("Delay entre envios: " . ($obj->delay / 1000) . " ms");
    
    // Informações do remetente
    $obj->senderName = $params['nome'] ?? null;
    debugLn("Nome do remetente: {$obj->senderName}");
    
    $obj->senderEmail = $params['de'] ?? null;
    debugLn("Email do remetente: {$obj->senderEmail}");
    
    // Validar formato do email do remetente
    if($obj->senderEmail && !filter_var($obj->senderEmail, FILTER_VALIDATE_EMAIL)) {
        writeLn("Email do remetente inválido: {$obj->senderEmail}", WHITE, RED, BOLD);
        exit(1);
    }
    
    // Assunto
    $obj->subject = $params['assunto'] ?? null;
    debugLn("Assunto: {$obj->subject}");
    
    // Inicializar array de destinatários
    $obj->targets = [];
    
    // Carregar conteúdo e anexo
    try {
        // Conteúdo da mensagem
        if(isset($params['conteudo'])) {
            $contentFile = $params['conteudo'];
            debug("Carregando conteúdo de '$contentFile'...");
            
            if(!file_exists($contentFile)) {
                throw new Exception("Arquivo de conteúdo não encontrado: $contentFile");
            }
            
            $obj->content = file_get_contents($contentFile);
            if($obj->content === false) {
                throw new Exception("Não foi possível ler o arquivo: $contentFile");
            }
            
            debugOk();
            debugLn("  Tamanho: " . strlen($obj->content) . " bytes");
        } else {
            $obj->content = null;
        }
        
        // Anexo (opcional)
        if(isset($params['anexo']) && !empty($params['anexo'])) {
            $attachFile = $params['anexo'];
            debug("Carregando anexo '$attachFile'...");
            
            if(!file_exists($attachFile)) {
                debugFail("Arquivo não encontrado");
                $obj->attachment = null;
                $obj->attachmentName = null;
            } else {
                $obj->attachment = file_get_contents($attachFile);
                if($obj->attachment === false) {
                    debugFail("Não foi possível ler o arquivo");
                    $obj->attachment = null;
                    $obj->attachmentName = null;
                } else {
                    $obj->attachmentName = basename($attachFile);
                    debugOk();
                    debugLn("  Nome: {$obj->attachmentName}");
                    debugLn("  Tamanho: " . strlen($obj->attachment) . " bytes");
                }
            }
        } else {
            $obj->attachment = null;
            $obj->attachmentName = null;
            debugLn("Nenhum anexo fornecido");
        }
        
    } catch(Exception $e) {
        writeLn($e->getMessage(), WHITE, RED, BOLD);
        exit(1);
    }
    
    // Adicionar destinatário único (--para)
    if(isset($params['para']) && !empty($params['para'])) {
        $email = trim($params['para']);
        if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $obj->targets[] = $email;
            debugLn("Destinatário adicionado: $email");
        } else {
            debugLn("Email inválido ignorado: $email", YELLOW);
        }
    }
    
    // Carregar lista de destinatários (--lista)
    if(isset($params['lista'])) {
        $listFile = $params['lista'];
        
        if(!file_exists($listFile)) {
            writeLn("Arquivo de lista não encontrado: $listFile", WHITE, RED, BOLD);
            exit(1);
        }
        
        if(!is_readable($listFile)) {
            writeLn("Arquivo de lista sem permissão de leitura: $listFile", WHITE, RED, BOLD);
            exit(1);
        }
        
        debugLn("Carregando lista de destinatários de '$listFile'...");
        
        $fhandle = fopen($listFile, 'r');
        if($fhandle === false) {
            writeLn("Não foi possível abrir o arquivo: $listFile", WHITE, RED, BOLD);
            exit(1);
        }
        
        $lineNum = 0;
        $validCount = 0;
        $invalidCount = 0;
        
        while(!feof($fhandle)) {
            $lineNum++;
            $line = trim(fgets($fhandle));
            
            // Ignorar linhas vazias e comentários
            if(empty($line) || strpos($line, '#') === 0) {
                continue;
            }
            
            // Validar email
            if(filter_var($line, FILTER_VALIDATE_EMAIL)) {
                // Evitar duplicatas
                if(!in_array($line, $obj->targets)) {
                    $obj->targets[] = $line;
                    $validCount++;
                    debugLn("  Linha $lineNum: $line ✓", GREEN);
                } else {
                    debugLn("  Linha $lineNum: $line (duplicado)", YELLOW);
                }
            } else {
                $invalidCount++;
                debugLn("  Linha $lineNum: '$line' (inválido)", RED);
            }
        }
        
        fclose($fhandle);
        
        debugLn("Lista processada: $validCount válidos, $invalidCount inválidos");
    }
    
    // Remover duplicatas finais e reindexar
    $obj->targets = array_values(array_unique($obj->targets));
    
    // Validar parâmetros obrigatórios
    try {
        validateParams($obj);
    } catch(Exception $e) {
        writeLn($e->getMessage(), WHITE, RED, BOLD);
        exit(1);
    }
    
    return $obj;
}

/**
 * Valida os parâmetros obrigatórios
 */
function validateParams(object $params): void {
    debugLn('');
    debugLn('Validando parâmetros...');
    
    $errors = [];
    
    // Verificar nome do remetente
    debug('Verificando nome do remetente...');
    if(empty($params->senderName)) {
        $errors[] = "Nome do remetente não fornecido (use --nome)";
        debugFail();
    } else {
        debugOk();
    }
    
    // Verificar email do remetente
    debug('Verificando email do remetente...');
    if(empty($params->senderEmail)) {
        $errors[] = "Email do remetente não fornecido (use --de)";
        debugFail();
    } elseif(!filter_var($params->senderEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email do remetente inválido: {$params->senderEmail}";
        debugFail();
    } else {
        debugOk();
    }
    
    // Verificar assunto
    debug('Verificando assunto...');
    if(empty($params->subject)) {
        $errors[] = "Assunto não fornecido (use --assunto)";
        debugFail();
    } else {
        debugOk();
    }
    
    // Verificar conteúdo
    debug('Verificando conteúdo...');
    if(empty($params->content)) {
        $errors[] = "Conteúdo não fornecido ou arquivo vazio (use --conteudo)";
        debugFail();
    } else {
        debugOk();
    }
    
    // Verificar destinatários
    debug('Verificando destinatários...');
    if(count($params->targets) === 0) {
        $errors[] = "Nenhum destinatário válido fornecido (use --para ou --lista)";
        debugFail();
    } else {
        debugOk();
        debugLn("  Total de destinatários: " . count($params->targets));
    }
    
    // Se houver erros, exibir todos e sair
    if(!empty($errors)) {
        writeLn('', WHITE);
        writeLn('ERROS ENCONTRADOS:', WHITE, RED, BOLD);
        foreach($errors as $error) {
            writeLn("  ✗ $error", RED);
        }
        writeLn('', WHITE);
        writeLn('Use --debug para mais detalhes', YELLOW);
        exit(1);
    }
    
    debugLn('Todos os parâmetros validados com sucesso!', GREEN);
}

/**
 * Verifica se o sendmail está instalado
 */
function verifySendMail(): void {
    $sendmailPaths = [
        '/usr/sbin/sendmail',
        '/usr/bin/sendmail',
        '/usr/lib/sendmail'
    ];
    
    $found = false;
    foreach($sendmailPaths as $path) {
        if(is_file($path) && is_executable($path)) {
            $found = true;
            debugLn("Sendmail encontrado em: $path", GREEN);
            break;
        }
    }
    
    if(!$found) {
        writeLn('', WHITE);
        writeLn('ERRO: Sendmail não encontrado!', WHITE, RED, BOLD);
        writeLn('', WHITE);
        writeLn('Para instalar, execute um dos comandos abaixo:', YELLOW);
        writeLn('', WHITE);
        writeLn('  Para Postfix (recomendado):', WHITE);
        writeLn('  sudo apt-get install postfix', CYAN);
        writeLn('', WHITE);
        writeLn('  Para Sendmail tradicional:', WHITE);
        writeLn('  sudo apt-get install sendmail', CYAN);
        writeLn('', WHITE);
        writeLn('Após a instalação, execute este script novamente.', YELLOW);
        writeLn('', WHITE);
        exit(1);
    }
}

/**
 * Exibe ajuda de uso do script
 */
function showHelp(): void {
    writeLn('', WHITE);
    writeLn('USO DO SCRIPT DE ENVIO DE EMAIL', WHITE, BLUE, BOLD);
    writeLn('', WHITE);
    writeLn('Sintaxe:', YELLOW);
    writeLn('  php send.php [opções]', WHITE);
    writeLn('', WHITE);
    writeLn('Opções obrigatórias:', YELLOW);
    writeLn('  --nome <nome>       Nome do remetente', WHITE);
    writeLn('  --de <email>        Email do remetente', WHITE);
    writeLn('  --assunto <texto>   Assunto do email', WHITE);
    writeLn('  --conteudo <arquivo> Arquivo HTML com o conteúdo', WHITE);
    writeLn('', WHITE);
    writeLn('Destinatários (usar pelo menos um):', YELLOW);
    writeLn('  --para <email>      Email único de destino', WHITE);
    writeLn('  --lista <arquivo>   Arquivo com lista de emails (um por linha)', WHITE);
    writeLn('', WHITE);
    writeLn('Opções adicionais:', YELLOW);
    writeLn('  --anexo <arquivo>   Arquivo para anexar', WHITE);
    writeLn('  --delay <ms>        Delay entre envios em milissegundos (padrão: 2000)', WHITE);
    writeLn('  --debug             Ativa modo de depuração', WHITE);
    writeLn('  --help              Exibe esta ajuda', WHITE);
    writeLn('', WHITE);
    writeLn('Exemplos:', YELLOW);
    writeLn('  Envio simples:', WHITE);
    writeLn('  php send.php --nome "João" --de joao@exemplo.com --assunto "Teste" \\', CYAN);
    writeLn('               --para destino@exemplo.com --conteudo msg.html', CYAN);
    writeLn('', WHITE);
    writeLn('  Envio em massa com anexo:', WHITE);
    writeLn('  php send.php --nome "Empresa XYZ" --de noreply@xyz.com \\', CYAN);
    writeLn('               --assunto "Newsletter" --lista emails.txt \\', CYAN);
    writeLn('               --conteudo newsletter.html --anexo catalogo.pdf \\', CYAN);
    writeLn('               --delay 3000 --debug', CYAN);
    writeLn('', WHITE);
}

// Verificar se foi solicitada ajuda
$argv = $_SERVER['argv'] ?? [];
if(isset($argv[1]) && in_array($argv[1], ['--help', '-h', '-?', 'help'])) {
    showHelp();
    exit(0);
}