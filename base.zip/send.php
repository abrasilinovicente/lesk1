<?php
require('src/utils.php');
require('src/email.php');

// Verificar sendmail antes de tudo
verifySendMail();

// Obter parâmetros validados
$params = getParams();

// Variável não utilizada - pode remover se não for necessária
// $rndStr = generateRandomString();

$totalTargets = count($params->targets);

// Verificar se há destinatários
if ($totalTargets === 0) {
    writeLn('Nenhum destinatário encontrado!', WHITE, RED);
    exit(1);
}

// Estatísticas de envio
$successCount = 0;
$failCount = 0;

foreach($params->targets as $i => $to) {
    $current = $i + 1;
    
    write("Enviando email $current de $totalTargets para ", WHITE);
    writeLn($to, YELLOW, DEFAULT_COLOR);
    
    // Enviar email com tratamento adequado de anexos
    $result = sendEmail(
        $params->senderName, 
        $params->senderEmail,
        $to,
        $params->subject,
        $params->content,
        $params->attachment ?? null,      // Usar null em vez de string vazia
        $params->attachmentName ?? null   // Usar null em vez de string vazia
    );
    
    if ($result) {
        writeLn("Email enviado para $to", GREEN);
        $successCount++;
    } else {
        writeLn("Não foi possível enviar email para $to", RED);
        $failCount++;
    }
    
    // Aplicar delay apenas se não for o último email
    if ($current < $totalTargets) {
        usleep($params->delay);
    }
}

// Mostrar resumo
writeLn('', WHITE);
writeLn('=== RESUMO DA EXECUÇÃO ===', WHITE, BLUE);
writeLn("Emails enviados com sucesso: $successCount", GREEN);
if ($failCount > 0) {
    writeLn("Emails com falha: $failCount", RED);
}
writeLn('Execução finalizada.', WHITE, BLUE);

// Retornar código de saída apropriado
exit($failCount > 0 ? 1 : 0);